export const GlobalConstants = {
    fileStatus: {
        Added: { status: 'Added' },
        Updated: { status: 'Updated' },
        Deleted: { status: 'Deleted' },
        Empty: { status: 'Empty' }
    }
};
