export type ButtonStyles = 'flat' | 'gradient';

export const ButtonStyles = {
    Flat: 'flat' as ButtonStyles,
    Gradient: 'gradient' as ButtonStyles
};
