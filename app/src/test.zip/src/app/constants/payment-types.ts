export enum PaymentTypes {
    AUS = 1,
    NZ = 2,
    INTL = 3,
}
// export type PaymentTypes = (typeof PaymentTypes)[keyof typeof PaymentTypes];

// export const PaymentTypes = {
//     AUS: 'Australia' as 'Australia',
//     NZ: 'New Zeland' as 'New Zeland',
//     INTL: 'International' as 'International'
// };

