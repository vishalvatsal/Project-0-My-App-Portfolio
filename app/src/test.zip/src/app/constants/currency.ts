export enum Currency {
    AUD = 1,
    NZD = 2
}
