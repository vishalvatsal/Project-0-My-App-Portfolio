export enum EligibilityQuestions {
    None = 0,
    Travelers = 1,
    Spending = 2,
    Default = 3 // Travelers | Spending
}
