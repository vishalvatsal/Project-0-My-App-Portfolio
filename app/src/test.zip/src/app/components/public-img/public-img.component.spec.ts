import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { PublicImgComponent } from './public-img.component';

describe('PublicImgComponent', () => {
  let component: PublicImgComponent;
  let fixture: ComponentFixture<PublicImgComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ PublicImgComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(PublicImgComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
