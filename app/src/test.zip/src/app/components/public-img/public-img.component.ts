import {
  Component, ViewChild, Input, Output,
  OnChanges, EventEmitter
} from '@angular/core';
import { NgForm} from '@angular/forms';
import { ImagecardsComponent } from '../imagecards/imagecards.component';
import { GlobalConstants } from '../../GlobalConstants';

@Component({
  selector: 'app-public-img',
  templateUrl: './public-img.component.html',
  styleUrls: ['./public-img.component.css'],
  providers: []
})
export class PublicImgComponent implements OnChanges {

  @Input()
  publicImgModel: any;

  @Output() currentChanges: EventEmitter<any> = new EventEmitter<any>();

  constructor() {
  }

  ngOnChanges(): void { }

  updateCurrent(form: any) {
    this.currentChanges.emit(form);
  }

}
