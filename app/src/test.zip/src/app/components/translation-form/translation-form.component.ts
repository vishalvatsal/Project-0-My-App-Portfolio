import {
  Component, ViewChild, Input, Output, OnInit, OnChanges, EventEmitter, ElementRef
} from '@angular/core';

import { NgForm, Validators } from '@angular/forms';
import { MarkdowneditorComponent } from '../markdowneditor/markdowneditor.component';
import { ITranslation } from '../../model/translation';

@Component({
  selector: 'app-translation-form',
  templateUrl: './translation-form.component.html',
  styleUrls: ['./translation-form.component.css']
})

export class TranslationFormComponent implements OnInit, OnChanges {
  @Input()
  original: ITranslation;

  @Input()
  current: ITranslation;

  @Output()
  public currentChanges: EventEmitter<any> = new EventEmitter<any>();

  @ViewChild('disclaimer') disclaimer: MarkdowneditorComponent;
  constructor() {
  }

  updateCurrent() {
    this.currentChanges.emit(this.current);
  }

  ngOnInit(): void { }

  ngOnChanges(): void {
    console.log('Translation changes');
    if (this.original !== undefined && this.current !== undefined) {
      if (this.current.footer.disclaimer === undefined) {
        this.disclaimer.original = this.original.footer.disclaimer;
      }
    }
  }

  resetTranslations(event: any) {
    if (event === null) {
      if (this.original !== undefined) {
        if (this.original.footer !== undefined) {
          this.disclaimer.original = this.original.footer.disclaimer;
        }
      }
    }
  }
}
