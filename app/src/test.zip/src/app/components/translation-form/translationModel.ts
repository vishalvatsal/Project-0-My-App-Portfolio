export class TranslationModel {
    header = {
        condensed_title: '',
        non_emergency_condensed_title: '',
    };
    footer = {
        disclaimer: '',
        company_name: '',
        abn: '',
        copyright: '',
        termsOfUse: '',
        privacyAndSecurity: '',
    };
    yourDetails = {
        validationTypeTooltip: '',
        yourCoverSubHeader: '',
        yourCoverCreditCard: '',
        needFindPolicy: '',
        claimingWith: '',
        policyText: '',
        creditcardText: '',
    };
    tripDetails = {
        purchasedWithCreditCardCount: '',
        purchasedWithCreditCard: '',
        agentAndBrokerAuthorisation: '',
        authorisedPerson: '',
    };
    eventDetails = {
        timeIncidentOccurred: '',
        didTheIncidentOccurOnCruiseShip: '',
        locationOfIncident: '',
        locationOfEventTooltip: '',
    };
    common = {
        next: '',
    };
    paymentDetails = {
        financialInstitutions: '',
    };
}
