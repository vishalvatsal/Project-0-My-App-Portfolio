import {
  Component, Input, Output, OnInit, EventEmitter, OnChanges, ViewChild, ElementRef
} from '@angular/core';
import { MatSelectChange } from '@angular/material';

import { NgForm, Validators } from '@angular/forms';
import { PaymentTypes } from '../../constants/payment-types';
import { Currency } from '../../constants/currency';
import { EligibilityQuestions } from '../../constants/eligibility-questions';
import { IConfig } from '../../model/config';

@Component({
  selector: 'app-config-form',
  templateUrl: './config-form.component.html',
  styleUrls: ['./config-form.component.css']
})

export class ConfigFormComponent implements OnInit, OnChanges {

  private currentValue: IConfig = {};
  private paymentTypes = PaymentTypes;
  private currency = Currency;
  private eligibilityQuestions = EligibilityQuestions;

  private paymentTypesKeys: any;
  private currencyKeys: any;
  private eligibilityQuestionsKeys: any;
  private allowedPaymentTypesPlaceHolder = [];
  @Input()
  original: IConfig = {};

  @Input()
  current: IConfig = {};

  @Output()
  public currentChanges: EventEmitter<any> = new EventEmitter<any>();

  @ViewChild('paymentTypesDropDown') paymentTypesDropDown: ElementRef;
  constructor() {
    this.paymentTypesKeys = Object.keys(this.paymentTypes).filter(Number);
    this.currencyKeys = Object.keys(this.currency).filter(Number);
    this.eligibilityQuestionsKeys = Object.keys(this.eligibilityQuestions).filter(Number);
  }

  ngOnInit(): void { }

  ngOnChanges(): void {
    if (this.original !== undefined) {
      this.allowedPaymentTypesPlaceHolder = this.original.uiSettings.allowedPaymentTypes;
    }
  }

  updateCurrent() {
    this.currentChanges.emit(this.current);
  }

  selectedChangeEvent(event: any) {
    if (event.value.length === 0) {
      this.allowedPaymentTypesPlaceHolder = [];
    } else {
      this.allowedPaymentTypesPlaceHolder = this.original.uiSettings.allowedPaymentTypes;
    }
  }

  resetPaymentTypes(event: any) {
    if (event === null) {
      this.allowedPaymentTypesPlaceHolder = this.original.uiSettings.allowedPaymentTypes;
    }
  }
}
