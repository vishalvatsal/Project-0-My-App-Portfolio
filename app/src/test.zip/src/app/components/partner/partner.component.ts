import { Component } from '@angular/core';
import { Http } from '@angular/http';
import { Router } from '@angular/router';
import { PartnerService } from '../../services/partner.services';
import { CloneDialogService } from '../../services/clone-Dialog.service';
import { CloneDialogComponent } from '../../components/clone-dialog/clone-dialog.component';
import { Observable } from 'rxjs/Rx';
import { ActivatedRoute } from '@angular/router';
import { MatDialog, MatDialogRef, MAT_DIALOG_DATA } from '@angular/material';


@Component({
  selector: 'app-partner',
  templateUrl: './partner.component.html',
  styleUrls: ['./partner.component.css']
})
export class PartnerComponent {
  errorMessage: string;
  partners$: Observable<any>;
  name: string;
  region: string;
  public result: any;

  constructor(private router: Router,
    private partnerService: PartnerService,
    private route: ActivatedRoute,
    public cloneDialogService: CloneDialogService) {

    this.name = this.route.snapshot.params['name'];
    this.region = this.route.snapshot.params['region'];
    // Load all environments
    this.partners$ = this.partnerService.getAllPartners(this.name, this.region);
  }

  public getPartnerDetails(partnerCode) {
    this.router.navigate([partnerCode], { relativeTo: this.route });
  }

  public clonePartner(partnerCode: string) {
    console.log('clonePartner');

    this.cloneDialogService
      .confirm(partnerCode)
      .subscribe(res => {
        console.log(res);
        // this.result = {};
        // this.result.code = res.code;
        // this.result.clientIds = res.clientIds.split(',');
        // this.partnerService.clonePartner(this.name, this.region, partnerCode, this.result);
      });
  }
}
