import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { FieldResetComponent } from './field-reset.component';

describe('FieldResetComponent', () => {
  let component: FieldResetComponent;
  let fixture: ComponentFixture<FieldResetComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ FieldResetComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(FieldResetComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
