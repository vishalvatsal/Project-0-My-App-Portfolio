import { Component, Input, Output, EventEmitter, OnInit } from '@angular/core';

@Component({
  selector: 'app-field-reset',
  templateUrl: './field-reset.component.html',
  styleUrls: ['./field-reset.component.css']
})

export class FieldResetComponent implements OnInit {

  private currentValue: any = null;

  @Input()
  public original: any;

  @Input()
  get current(): any {
    return this.currentValue;
  }

  @Output()
  public currentChange: EventEmitter<any> = new EventEmitter<any>();
  set current(value: any) {
    this.currentValue = value;
    this.currentChange.emit(this.currentValue);
  }

  public reset() {
    this.current = null;
  }

  public get tooltip(): string {
    return 'Restore to ' + this.original;
  }

  constructor() { }

  ngOnInit(): void {
  }

}
