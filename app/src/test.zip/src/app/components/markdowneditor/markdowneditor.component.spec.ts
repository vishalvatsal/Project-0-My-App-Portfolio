import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { MarkdowneditorComponent } from './markdowneditor.component';

describe('MarkdowneditorComponent', () => {
  let component: MarkdowneditorComponent;
  let fixture: ComponentFixture<MarkdowneditorComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ MarkdowneditorComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(MarkdowneditorComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
