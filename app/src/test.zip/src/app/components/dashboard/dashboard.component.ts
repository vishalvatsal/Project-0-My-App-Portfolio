import { Component, OnInit } from '@angular/core';
import { Http } from '@angular/http';
import { Router } from '@angular/router';
import { EnvironmentService } from '../../services/environment.service';
import { IEnvironment } from '../../config/model/config';
import { Observable } from 'rxjs/Rx';


@Component({
  selector: 'app-dashboard',
  templateUrl: './dashboard.component.html',
  styleUrls: ['./dashboard.component.css']
})
export class DashboardComponent implements OnInit {
  environments: IEnvironment[];
  errorMessage: string;

  constructor(private router: Router, private _environmentservice: EnvironmentService) {
    this.environments = [];
  }

  ngOnInit() {
    this.getAllEnvironments()
      .subscribe(response => {
        this.environments = response;
      }
      , error => this.errorMessage = <any>error);
  }

  // Gets the local json file
  public getAllEnvironments(): Observable<any> {
    return this._environmentservice.getEnvironments();
  }

  public getAllPartners(environment) {
    this.router.navigateByUrl('/' + environment.name + '/' + environment.region);
  }
}
