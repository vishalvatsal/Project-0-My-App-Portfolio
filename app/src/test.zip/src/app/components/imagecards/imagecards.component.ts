import {
  Component, ViewChild, Input, Output, OnChanges,
  OnInit, EventEmitter, ElementRef
} from '@angular/core';
import { NgForm, FormBuilder, FormGroup, Validators } from '@angular/forms';
import { ImageCropperComponent, CropperSettings } from 'ng2-img-cropper';
import { GlobalConstants } from '../../GlobalConstants';

@Component({
  selector: 'app-imagecards',
  templateUrl: './imagecards.component.html',
  styleUrls: ['./imagecards.component.css'],
  providers: []
})
export class ImagecardsComponent implements OnInit, OnChanges {

  private globalConstants = GlobalConstants;
  private currentValue: any;

  @Input()
  original: any;

  @Input()
  current: any;

  @Output()
  public currentChanges: EventEmitter<any> = new EventEmitter<any>();

  cropperSettings: CropperSettings;
  @ViewChild('cropper', undefined) cropper: ImageCropperComponent;
  @ViewChild('imageCropper') imageCropper: ElementRef;
  @ViewChild('originalImage') originalImage: ElementRef;
  constructor() {
    this.cropperSettings = new CropperSettings();
    this.cropperSettings.width = 200;
    this.cropperSettings.height = 100;
    this.cropperSettings.minWidth = 200;
    this.cropperSettings.minHeight = 100;
    this.cropperSettings.croppedWidth = 200;
    this.cropperSettings.croppedHeight = 100;
    this.cropperSettings.canvasWidth = 600;
    this.cropperSettings.canvasHeight = 300;
    this.cropperSettings.keepAspect = true;
    // this.cropperSettings.allowedFilesRegex = new RegExp('/.(jpe?g|png)$/i');
    this.cropperSettings.noFileInput = true;
  }

  ngOnInit() {
  }

  ngOnChanges() {

    if (Object.getOwnPropertyNames(this.current.file).length === 0) {
      this.displayOriginalImage();
    } else {
      this.displayOriginalImage();
    }
  }

  onImageAdd(form: any) {
   this.current.file = form.value.image;
    this.current.fileStatus = GlobalConstants.fileStatus.Added;
    this.current.isDirty = true;
    this.updateCurrent();
  }

  onImageRemove() {
    this.displayOriginalImage();
    this.current.file = {};
    this.current.fileStatus = GlobalConstants.fileStatus.Deleted;
    this.current.isDirty = true;
    this.updateCurrent();
  }

  updateCurrent() {
    this.currentChanges.emit(this.current);
  }

  displayOriginalImage() {
    if (Object.getOwnPropertyNames(this.original.file).length !== 0) {
      this.originalImage.nativeElement.hidden = false;
    } else {
      this.originalImage.nativeElement.hidden = true;
    }
  }

  cancleUpload($event) {
    const that = this;
    that.cropper.reset();
    that.imageCropper.nativeElement.hidden = true;
    that.originalImage.nativeElement.hidden = false;
  }

  /**
     * Used to send image to second cropper
     * @param $event
     */
  fileChangeListener($event) {
    const image: any = new Image();
    const file: File = $event.target.files[0];
    const myReader: FileReader = new FileReader();
    const that = this;
    myReader.onloadend = function (loadEvent: any) {
      image.src = loadEvent.target.result;
      that.imageCropper.nativeElement.hidden = false;
      that.originalImage.nativeElement.hidden = true;
      that.cropper.setImage(image);

    };

    myReader.readAsDataURL(file);
  }
}
