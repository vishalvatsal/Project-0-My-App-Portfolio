import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ImagecardsComponent } from './imagecards.component';

describe('ImagecardsComponent', () => {
  let component: ImagecardsComponent;
  let fixture: ComponentFixture<ImagecardsComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ImagecardsComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ImagecardsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
