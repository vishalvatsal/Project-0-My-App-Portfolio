import { Component, AfterViewInit, ViewChild, OnInit } from '@angular/core';
import { Http } from '@angular/http';
import { Router } from '@angular/router';
import * as JSZip from 'jszip';
import * as JSZipUtils from 'jszip-utils';
import * as jsonminify from 'jsonminify';
import { EnvironmentService } from '../../services/environment.service';
import { IEnvironment } from '../../config/model/config';
import { FileService } from '../../services/file.service';
import { PartnerService } from '../../services/partner.services';
import { Observable } from 'rxjs/Rx';
import { ActivatedRoute } from '@angular/router';
import { NgForm, FormBuilder, FormGroup, Validators } from '@angular/forms';
import { DomSanitizer, SafeUrl, SafeResourceUrl } from '@angular/platform-browser';
import { GlobalConstants } from '../../GlobalConstants';
import { IConfig } from '../../model/config';
import { ITranslation } from '../../model/translation';
import { IFile, EmailTemplateFiles, PublicImgFiles } from '../../model/files';


@Component({
  selector: 'app-partner-details',
  templateUrl: './partner-details.component.html',
  styleUrls: ['./partner-details.component.css'],
  providers: []
})
export class PartnerDetailsComponent implements OnInit, AfterViewInit {


  errorMessage: string;

  name: string;
  region: string;
  partner: string;

  private listOfFileToModify: any[];

  defaultZipfiles: any[];
  currentZipFiles: any[];
  status: any[];


  zipblob: any;

  private translationObject: ITranslation;
  private configObject: IConfig;

  private emailTemplateObject: any[];
  private emailTemplate: any = EmailTemplateFiles;

  private publicImgTemplateObject: any[];
  private publicImgModel: any = PublicImgFiles;

  private translationObject_Default: ITranslation;
  private configObject_Default: IConfig;
  private emailTemplateObject_Default: any[];
  private publicImgTemplateObject_Default: any[];

  constructor(
    private router: Router,
   private partnerService: PartnerService,
    private route: ActivatedRoute,
    private domSanitizer: DomSanitizer,
    private formBuilder: FormBuilder) {


    this.configObject = <IConfig>{
      emailSettings: {},
      uiSettings: {},
      theme: {
        variables: {}
      }
    };

    this.translationObject = <ITranslation>{
      footer: {}
    };

    this.name = this.route.snapshot.params['name'];
    this.region = this.route.snapshot.params['region'];
    this.partner = this.route.snapshot.params['partner'];

    this.currentZipFiles = [];
    this.defaultZipfiles = [];
  }

  ngOnInit() {

    // Get the default partner
    this.partnerService.getPartner(this.name, this.region, '_default')
      .subscribe(x => {
        const vm = this;
        vm.defaultZipfiles = x;

        vm.defaultZipfiles.forEach(file => {

          if (file.name === 'translation.json') {
            vm.translationObject_Default = JSON.parse(jsonminify(file.file.toString().trim()));
          }
          if (file.name === 'config.json') {
            vm.configObject_Default = JSON.parse(jsonminify(file.file.toString().trim()));
          }
        });

        vm.loadOriginalObject(vm.defaultZipfiles);
      });



    this.partnerService.getPartner(this.name, this.region, this.partner)
      .subscribe(x => {
        const vm = this;
        vm.currentZipFiles = x;

        vm.currentZipFiles.forEach(file => {

          if (file.name === 'translation.json') {

            vm.translationObject = this.mergeDeep(vm.translationObject, JSON.parse(jsonminify(file.file.toString().trim())));
          }
          if (file.name === 'config.json') {

            vm.configObject = this.mergeDeep(vm.configObject, JSON.parse(jsonminify(file.file.toString().trim())));

          }
        });

        vm.loadCurrentObject(vm.currentZipFiles);
      });
  }

  public loadOriginalObject(files: any[]) {
    this.emailTemplate.files.forEach(x => {
      const f = files.find(file => file.name === x.zipFileName);
      if (f !== undefined) {
        x.zipFileObjectOriginal = f;
      } else {
        x.zipFileObjectOriginal = { name: x.zipFileName, file: {}, folder: x.folderName, isDirty: false, fileStatus: GlobalConstants.fileStatus.Empty };
      }
    });

    this.publicImgModel.files.forEach(x => {
      const f = files.find(file => file.name === x.zipFileName);
      if (f !== undefined) {
        x.zipFileObjectOriginal = f;
      } else {
        x.zipFileObjectOriginal = { name: x.zipFileName, file: {}, folder: x.folderName, isDirty: false, fileStatus: GlobalConstants.fileStatus.Empty };
      }
    });


  }

  public loadCurrentObject(files: any[]) {
    this.emailTemplate.files.forEach(x => {
      const f = files.find(file => file.name === x.zipFileName);
      if (f !== undefined) {
        x.zipFileObjectCurrent = f;
      } else {
        x.zipFileObjectCurrent = { name: x.zipFileName, file: {}, folder: x.folderName, isDirty: false, fileStatus: GlobalConstants.fileStatus.Empty };
      }
    });

    this.publicImgModel.files.forEach(x => {
      const f = files.find(file => file.name === x.zipFileName);
      if (f !== undefined) {
        x.zipFileObjectCurrent = f;
      } else {
        x.zipFileObjectCurrent = { name: x.zipFileName, file: {}, folder: x.folderName, isDirty: false, fileStatus: GlobalConstants.fileStatus.Empty };
      }
    });
  }


  ngAfterViewInit(): void { }

  handleOnSubmitTranslation(form: ITranslation) {

    console.log('submit from translation=');
    console.log(form);

    // get the object from array
    // console.log('submit from Chile=' + form.value.disclaimer);
    const r = this.currentZipFiles.findIndex(x => x.name === 'translation.json');

    if (r >= 0) {
      console.log(r);
      console.log(this.currentZipFiles[r]);

      this.currentZipFiles[r].file = form;
      this.currentZipFiles[r].isDirty = true;
      this.currentZipFiles[r].fileStatus = GlobalConstants.fileStatus.Updated;


    }
  }

  handleOnSubmitConfig(form: IConfig) {
    // get the object from array
    console.log('submit from child Config=');
    console.log(form);
    const r = this.currentZipFiles.findIndex(x => x.name === 'config.json');

    if (r >= 0) {
      this.currentZipFiles[r].file = form;
      this.currentZipFiles[r].isDirty = true;
      this.currentZipFiles[r].fileStatus = GlobalConstants.fileStatus.Updated;
    }
  }

  handleOnSubmitEmailTemplate() {
    console.log('submit from email templates=');

    this.emailTemplate.files.forEach(element => {
      if (element.zipFileObjectCurrent.isDirty) {
        this.updateCurrentZipFiles(element);
      }
    });

    // this.updateEmailTemplateModel(form);
    // this.updateCurrentZipFiles(form);
    console.log('End submit from email templates');
  }

  private updateEmailTemplateModel(form: any) {
    const r = this.emailTemplate.findIndex(x => x.name === form.name);
    console.log(r);
    console.log(this.emailTemplate[r]);
    if (r >= 0) {
      //  this.emailTemplate[r].file = form.file;
      //   this.emailTemplate[r].isDirty = true;
      //   this.emailTemplate[r].fileStatus = form.fileStatus;
    }
  }

  private updateCurrentZipFiles(imageTemplateFile: any) {
    // console.log(this.currentZipFiles);
    console.log(imageTemplateFile);
    const r = this.currentZipFiles.findIndex(x => x.name === imageTemplateFile.zipFileObjectCurrent.name);
    if (r >= 0) {
      this.currentZipFiles[r].file = imageTemplateFile.zipFileObjectCurrent.file;
      this.currentZipFiles[r].isDirty = true;
      this.currentZipFiles[r].fileStatus = imageTemplateFile.zipFileObjectCurrent.fileStatus;
    } else if (imageTemplateFile.zipFileObjectCurrent.isDirty) {
      this.currentZipFiles.push(imageTemplateFile.zipFileObjectCurrent);
    }
  }

  onSubmitFinalize() {
    // TODO: Might need to validate all the files.
    this.partnerService.updatePartner(this.name, this.region, this.partner, this.currentZipFiles);
  }


  isObject(item: any): boolean {
    return (item && typeof item === 'object' && !Array.isArray(item));
  }


  mergeDeep(target: any, source: any): any {
    let output = Object.assign({}, target);
    if (this.isObject(target) && this.isObject(source)) {
      Object.keys(source).forEach(key => {
        if (this.isObject(source[key])) {
          if (!(key in target)) {
            Object.assign(output, { [key]: source[key] });
          } else {
            output[key] = this.mergeDeep(target[key], source[key]);
          }
        } else {
          Object.assign(output, { [key]: source[key] });
        }
      });
    }
    return output;
  }

}
