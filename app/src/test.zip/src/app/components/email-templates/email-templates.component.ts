import {
  Component, ViewChild, Input, Output,
  OnInit, OnChanges, EventEmitter
} from '@angular/core';
import { NgForm, FormBuilder, FormGroup, Validators } from '@angular/forms';
import { ImagecardsComponent } from '../imagecards/imagecards.component';
import { GlobalConstants } from '../../GlobalConstants';

@Component({
  selector: 'app-email-templates',
  templateUrl: './email-templates.component.html',
  styleUrls: ['./email-templates.component.css'],
  providers: []
})
export class EmailTemplatesComponent implements OnInit, OnChanges {


  @Input()
  emailTemplate: any;

  @Output()
  public currentChanges: EventEmitter<any> = new EventEmitter<any>();

  constructor() {
  }

  ngOnInit(): void { }

  ngOnChanges(): void { }

  updateCurrent(form: any, index: number) {
    this.currentChanges.emit();
  }
}
