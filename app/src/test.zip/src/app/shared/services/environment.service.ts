import {Injectable} from '@angular/core';
import {Http, Response} from '@angular/http';
import {  
    Observable,  
    Subject  
} from 'rxjs/Rx';  
import 'rxjs/Rx'; //get everything from Rx    
import 'rxjs/add/operator/toPromise';  
import {IEnvironment} from '../../config/model/config'

@Injectable()
export class EnvironmentService{
    private jsonFileUrl:string ='/assets/config.json';

    constructor(private http:Http){

    }

    getEnvironments():Observable<IEnvironment[]>{
        return this.http.get(this.jsonFileUrl).map((response:Response) => {
            return <IEnvironment[]> response.json()
        }).catch(this.handleError)
    }

    private handleError(errorResponse:Response){
       
        console.log(errorResponse.statusText);
        return Observable.throw(errorResponse.json().error || "Server error"); 
    }
}