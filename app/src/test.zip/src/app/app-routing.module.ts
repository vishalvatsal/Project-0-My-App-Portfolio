import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';

import { DashboardComponent } from './components/dashboard/dashboard.component';
import { PartnerComponent } from './components/partner/partner.component';
import { PartnerDetailsComponent } from './components/partner-details/partner-details.component';

const routes: Routes = [
  {
    path: ':name/:region', component: PartnerComponent },
  { path: ':name/:region/:partner', component: PartnerDetailsComponent },
  { path: 'dashboard', component: DashboardComponent },
  { path: '', redirectTo: '/dashboard', pathMatch: 'full' },
];

@NgModule({
  imports: [
    RouterModule.forRoot(routes
     // , { enableTracing: true } // <-- debugging purposes only
    )
  ],
  exports: [
    RouterModule
  ]
})

export class AppRoutingModule {
}
