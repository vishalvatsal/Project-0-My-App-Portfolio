export interface ITranslation {
    header?: {
        condensed_title: string,
        non_emergency_condensed_title: string,
    };
    footer?: {
        disclaimer: string,
        company_name: string,
        abn: string,
        copyright: string,
        termsOfUse: string,
        privacyAndSecurity: string,
    };
    yourDetails?: {
        validationTypeTooltip: string,
        yourCoverSubHeader: string,
        yourCoverCreditCard: string,
        needFindPolicy: string,
        claimingWith: string,
        policyText: string,
        creditcardText: string,
    };
    tripDetails?: {
        purchasedWithCreditCardCount: string,
        purchasedWithCreditCard: string,
        agentAndBrokerAuthorisation: string,
        authorisedPerson: string,
    };
    eventDetails?: {
        timeIncidentOccurred: string,
        didTheIncidentOccurOnCruiseShip: string,
        locationOfIncident: string,
        locationOfEventTooltip: string,
    };
    common?: {
        next: string,
    };
    paymentDetails?: {
        financialInstitutions: string,
    };
}
