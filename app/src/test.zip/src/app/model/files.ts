import { GlobalConstants } from '../GlobalConstants';

export interface IZipFileObject {
    name: string;
    file: any;
    folder: string;
    isDirty: boolean;
    fileStatus: any;
}
export interface IFile {
    name: string;
    type: string;
    isFolder: boolean;
    folderName: any;
    isEditable: true;
    zipFileName: string;
    zipFileObjectOriginal: IZipFileObject;
    zipFileObjectCurrent: IZipFileObject;
}

export const EmailTemplateFiles = {
    files: [
        { name: 'logo-footer.png', type: 'Image', isFolder: false, folderName: 'emailTemplates', isEditable: true, zipFileName: 'emailTemplates\\logo-footer.png', zipFileObjectOriginal: <IZipFileObject>{isDirty: false, fileStatus: GlobalConstants.fileStatus.Empty, file: {}}, zipFileObjectCurrent: <IZipFileObject>{isDirty: false, fileStatus: GlobalConstants.fileStatus.Empty, file: {}} },
        { name: 'logo.png', type: 'Image', isFolder: false, folderName: 'emailTemplates', isEditable: true, zipFileName: 'emailTemplates\\logo.png', zipFileObjectOriginal: <IZipFileObject>{isDirty: false, fileStatus: GlobalConstants.fileStatus.Empty, file: {}}, zipFileObjectCurrent: <IZipFileObject>{isDirty: false, fileStatus: GlobalConstants.fileStatus.Empty, file: {}} },
        { name: 'email-banner-submitted.png', type: 'Image', isFolder: false, folderName: 'emailTemplates', isEditable: true, zipFileName: 'emailTemplates\\email-banner-submitted.png', zipFileObjectOriginal: <IZipFileObject>{isDirty: false, fileStatus: GlobalConstants.fileStatus.Empty, file: {}}, zipFileObjectCurrent: <IZipFileObject>{isDirty: false, fileStatus: GlobalConstants.fileStatus.Empty, file: {}} },
        { name: 'email-banner-saved.png', type: 'Image', isFolder: false, folderName: 'emailTemplates', isEditable: true, zipFileName: 'emailTemplates\\email-banner-saved.png', zipFileObjectOriginal: <IZipFileObject>{isDirty: false, fileStatus: GlobalConstants.fileStatus.Empty, file: {}}, zipFileObjectCurrent: <IZipFileObject>{isDirty: false, fileStatus: GlobalConstants.fileStatus.Empty, file: {}} },
       ],
};

export const PublicImgFiles = {
    files: [
        { name: 'favicon.ico', type: 'Image', isFolder: false, folderName: 'public/img', isEditable: true, zipFileName: 'public\\img\\favicon.ico', zipFileObjectOriginal: <IZipFileObject>{isDirty: false, fileStatus: GlobalConstants.fileStatus.Empty, file: {}}, zipFileObjectCurrent: <IZipFileObject>{isDirty: false, fileStatus: GlobalConstants.fileStatus.Empty, file: {}} },
        { name: 'logo.png', type: 'Image', isFolder: false, folderName: 'public/img', isEditable: true, zipFileName: 'public\\img\\logo.png', zipFileObjectOriginal: <IZipFileObject>{isDirty: false, fileStatus: GlobalConstants.fileStatus.Empty, file: {}}, zipFileObjectCurrent: <IZipFileObject>{isDirty: false, fileStatus: GlobalConstants.fileStatus.Empty, file: {}} },
        { name: 'header.jpg', type: 'Image', isFolder: false, folderName: 'public/img', isEditable: true, zipFileName: 'public\\img\\header.jpg', zipFileObjectOriginal: <IZipFileObject>{isDirty: false, fileStatus: GlobalConstants.fileStatus.Empty, file: {}}, zipFileObjectCurrent: <IZipFileObject>{isDirty: false, fileStatus: GlobalConstants.fileStatus.Empty, file: {}} }
      ],
};
