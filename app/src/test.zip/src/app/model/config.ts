import { Currency } from '../constants/currency';
import { ButtonStyles } from '../constants/buttons-styles';
import { EligibilityQuestions } from '../constants/eligibility-questions';
import { PaymentTypes } from '../constants/payment-types';



export interface IConfig {
    defaultCurrency?: Currency;
    emailSettings?: {
        includeAttachments?: boolean;
        fromEmail?: string;
    };
    eligibilityQuestions?: EligibilityQuestions;
    // tslint:disable-next-line:no-shadowed-variable
    uiSettings?: {
        allowedPaymentTypes?: PaymentTypes[];
    };
    code?: string; // only set when new
    isDefault?: boolean;
    emergencyPhoneNumber?: string;
    contactCentrePhoneNumber?: string; // wait for confirmation can be readonly
    contactCentreEmail?: string;
    clientIds?: Int32Array[]; // array of int
    theme?: {
        skinCode?: string; // readonly
        variables?: {
            ['primary-color']?: string;
            ['secondary-color']?: string;
            ['tertiary-color']?: string;
            ['button-style']?: ButtonStyles;
        };
    };
}
