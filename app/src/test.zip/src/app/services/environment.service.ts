import { Injectable } from '@angular/core';
import { Http, Response } from '@angular/http';
import {
    Observable,
    Subject
} from 'rxjs/Rx';
import 'rxjs/Rx'; // get everything from Rx
import 'rxjs/add/operator/toPromise';
import 'rxjs/add/operator/map';
import * as JSZip from 'jszip';
import * as JSZipUtils from 'jszip-utils';
import { IEnvironment } from '../config/model/config';


@Injectable()
export class EnvironmentService {
    private jsonFileUrl: string = '/assets/config.json';

    private loadFileFromLocal: string = '/assets/aga.zip';


    constructor(private http: Http) {

    }

    getEnvironments() {
        return this.http.get(this.jsonFileUrl).map((response: Response) => {
            return <IEnvironment[]>response.json();
        }).catch(this.handleError);
    }

    getEnvironment(name: string, region: string): Observable<IEnvironment> {
        return this.getEnvironments().map(x => x.find(y => y.name === name && y.region === region));
    }

    private handleError(errorResponse: Response) {
        console.log(errorResponse.statusText);
        return Observable.throw(errorResponse.json().error || 'Server error');
    }

    // getPartner(): Promise<any> {
    //     console.log('"getPartnerPromise"');
    //     // 1) get a promise of the content
    //     const promise = new JSZip.external.Promise(function (resolve, reject) {
    //         // 'https://localhost:44374/api/partnerAdministration/partner/aga'
    //         JSZipUtils.getBinaryContent('/assets/aga.zip', function (err, data) {
    //             if (err) {
    //                 reject(err);
    //             } else {
    //                 console.log('data');
    //                 resolve(data);
    //             }
    //         });
    //     });

    //     return promise;
    // }
}
