import { Injectable } from '@angular/core';
import { Observable } from 'rxjs/Observable';
import { CloneDialogComponent } from '../components/clone-dialog/clone-dialog.component';
import { MatDialogRef, MatDialog } from '@angular/material';

@Injectable()
export class CloneDialogService {

    constructor(private dialog: MatDialog) {
        console.log('Dialog Service');
    }

    public confirm(partnerCode: string): Observable<any> {
        console.log('in confirm');
        console.log(partnerCode);
        let dialogRef: MatDialogRef<CloneDialogComponent>;

        dialogRef = this.dialog.open(CloneDialogComponent,
            {
                data: {
                    cloneFromPartnerCode: partnerCode,
                    clientIds: [],
                    code: ''
                }
            });
        return dialogRef.afterClosed();
    }
}
