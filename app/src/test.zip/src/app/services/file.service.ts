import { Injectable } from '@angular/core';
import { Http, Response, Headers, RequestOptions } from '@angular/http';
import {
    Observable,
    Subject
} from 'rxjs/Rx';
import 'rxjs/Rx'; // get everything from Rx
import 'rxjs/add/operator/toPromise';
import 'rxjs/add/operator/map';
import 'rxjs/add/operator/catch';
import * as JSZip from 'jszip';
import * as JSZipUtils from 'jszip-utils';


@Injectable()
export class FileService {

    constructor(private http: Http) { }

    private handleError(error: any) {

        if (error instanceof Response) {
            return Observable.throw(error.json()['error'] || 'backend server error');
        }
        return Observable.throw(error || 'backend server error');
    }

    getAllPartners(url): Observable<any[]> {
        // console.log('In file service get all partners');
        // console.log(url);
        return this.http.get(url)
            .map((response: Response) => {
                return <any[]>response.json();
            }).catch(this.handleError);
    }

    getPartner(url) {
        // 1) get a promise of the content
        // console.log('url=' + url);
        const promise = new JSZip.external.Promise(function (resolve, reject) {
            JSZipUtils.getBinaryContent(url, function (err, data) {
                if (err) {
                    reject(err);
                } else {
                    // console.log('got data');
                    resolve(data);
                }
            });
        });

        // return promise;

        return Observable.fromPromise(JSZip.loadAsync(promise))
            .map(zip => {
                return <any>zip;
            });
    }

    getPartnerZip(url) {
        // 1) get a promise of the content
        // console.log('url=' + url);
        const promise = new JSZip.external.Promise(function (resolve, reject) {
            JSZipUtils.getBinaryContent(url, function (err, data) {
                if (err) {
                    reject(err);
                } else {
                    // console.log('got data');
                    resolve(data);
                }
            });
        });

        return promise;


    }

    upload(formData, url) {
        console.log('Upload now');
        return this.http.post(url, formData)
            .map(response => response.json())
            .catch(error => Observable.throw(error));

    }

    clonePartner(name, region, partner, data) {

    }

}
