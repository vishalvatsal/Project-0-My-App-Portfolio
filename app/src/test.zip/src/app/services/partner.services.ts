import { Injectable } from '@angular/core';
import { Http, Response, Headers, RequestOptions } from '@angular/http';
import {
    Observable,
    Subject
} from 'rxjs/Rx';
import 'rxjs/Rx'; // get everything from Rx
import 'rxjs/add/operator/toPromise';
import 'rxjs/add/operator/map';
import 'rxjs/add/operator/catch';
import * as JSZip from 'jszip';
import * as JSZipUtils from 'jszip-utils';
import * as jsonminify from 'jsonminify';
import { EnvironmentService } from './environment.service';
import { IEnvironment } from './../config/model/config';
import { FileService } from './file.service';
import { GlobalConstants } from '../GlobalConstants';
import { IConfig } from '../model/config';


@Injectable()
export class PartnerService {

    constructor(private fileService: FileService,
        private environmentService: EnvironmentService) {

    }

    public getAllPartners(name, region) {
        return this.environmentService.getEnvironment(name, region)
            .switchMap(x => {
                return this.fileService.getAllPartners(x.url);
            });
    }

    public getPartner(name, region, partner): Observable<any> {
        // const vm = this;
        return this.environmentService.getEnvironment(name, region)
            .switchMap(environment => this.fileService.getPartner(environment.url + '/' + partner))
            .switchMap(zip => {
                return Observable.from(Object.keys(zip.files))
                    .flatMap(response => {
                        return Observable.of(response)
                            .map(r => {

                                const file = zip.files[r];
                                // *** Check if dir are being returned now.
                                // if (file.dir) {
                                //   console.log('dir =' + r);
                                // } else {
                                //   console.log('filename =' + r);
                                // }
                                // *** End Check if dir are being returned now.
                                if (this.checkIfImage(r)) {
                                    return Observable.fromPromise(file.async('blob')).map(c => {
                                        const folderpath = r.substring(0, r.lastIndexOf('\\'));
                                        return <any>{ name: r, file: URL.createObjectURL(c), folder: folderpath, isDirty: false, fileStatus: {} };
                                    });
                                } else {
                                    return Observable.fromPromise(file.async('string')).map(c => {
                                        return <any>{ name: r, file: c.toString().trim(), folder: '', isDirty: false, fileStatus: {} };
                                    });
                                }

                            });

                    }).combineAll();
            });
    }

    public getPartnerZip(name, region, partner): Observable<any> {
        return this.environmentService.getEnvironment(name, region)
            .switchMap(environment => this.fileService.getPartner(environment.url + '/' + partner));
    }

    private checkIfImage(fileName) {
        const re = /(.jpg|.png|.gif|.ps|.jpeg)$/;

        return re.test(fileName.toLowerCase());
    }

    private dataURIToBlob(dataURI) {
        dataURI = dataURI.replace(/^data:/, '');
        const type = dataURI.match(/image\/[^;]+/);
        return dataURI.replace(/^[^,]+,/, '');
    }

    public cleanString(input) {
        let output = '';
        for (let i = 0; i < input.length; i++) {
            if (input.charCodeAt(i) <= 127) {
                output += input.charAt(i);
            }
        }
        return output;
    }

    public updatePartner(name, region, partner, zip) {
        this.getPartnerZip(name, region, partner)
            .subscribe(orizip => {
                // orizip.forEach((function (relativePath, zipEntry) {
                //     console.log(zipEntry);
                //     zipEntry.async('string');
                // }));

                zip.forEach(zipFile => {

                    if (zipFile.isDirty) {
                        console.log(zipFile.name);
                        if (zipFile.fileStatus === GlobalConstants.fileStatus.Added) {
                            if (this.checkIfImage(zipFile.name)) {
                                console.log('Added image...');
                                orizip.file(zipFile.folder + '\\' + zipFile.name, this.dataURIToBlob(zipFile.file), { base64: true });
                            } else {
                                console.log('Added other...');
                                orizip.file(zipFile.name, zipFile.file, { binary: true });
                            }
                        } else if (zipFile.fileStatus === GlobalConstants.fileStatus.Deleted) {
                            orizip.remove(zipFile.name);
                            console.log('Deleted...');

                        } else { // this is used for  json files
                            orizip.file(zipFile.name, JSON.stringify(zipFile.file, undefined, 4), { binary: false });
                            orizip.file(zipFile.name).async('string').then(function success(text) {
                                console.log(text);
                            });
                            console.log('updated...');
                        }
                    }
                });

                orizip.generateAsync({ type: 'blob', compression: 'DEFLATE', })
                    .then(zipBlob => {
                        // here send a post request using the zipBlob as a post parameter
                        console.log('gen zip blob');
                        const formData = new FormData();
                        formData.append('file', zipBlob);
                        console.log(zipBlob);
                        return this.environmentService.getEnvironment(name, region)
                            .switchMap(x => this.fileService.upload(formData, x.url + '/' + partner))
                            .subscribe(
                            success => {
                                console.log('uploaded');
                            },
                            error => {
                                console.log('error' + error);
                            });
                    });

            });
    }

    public clonePartner(name, region, partner, data) {
        this.getPartnerZip(name, region, partner)
            .subscribe(orizip => {
                const that = this;
                let configObject: IConfig;
                orizip.file('config.json').async('string')
                    .then(function success(text) {

                        configObject = JSON.parse(jsonminify(text.toString().trim()));
                        configObject.clientIds = data.clientIds;
                        configObject.code = data.code;
                        orizip.file('config.json', JSON.stringify(configObject, undefined, 4), { binary: false });
                        return true;
                    })
                    .then(function success(result) {
                        console.log('3');
                        orizip.generateAsync({ type: 'blob', compression: 'DEFLATE', })
                            .then(zipBlob => {
                                // const  that = this;
                                // here send a post request using the zipBlob as a post parameter
                                console.log('gen zip blob');
                                const formData = new FormData();
                                formData.append('file', zipBlob);
                                console.log(zipBlob);
                                that.environmentService.getEnvironment(name, region)
                                    .switchMap(x => that.fileService.upload(formData, x.url + '/' + data.code))
                                    .subscribe(
                                    success1 => {
                                        console.log('uploaded');
                                    },
                                    error => {
                                        console.log('error' + error);
                                    });
                            });

                    });
            });
    }
}
