export interface IEnvironment {
    id:string;
    name:string;
    region:string;
    url:string;
}