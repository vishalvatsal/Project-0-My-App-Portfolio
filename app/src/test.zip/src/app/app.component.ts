import { Component, OnInit } from '@angular/core';
import {MdToolbar} from '@angular/material';
import {Http} from '@angular/http';
import * as JSZip from 'jszip';
import {EnvironmentService} from './shared/services/environment.service';
import {IEnvironment} from './config/model/config'
import {Observable} from 'rxjs/Rx';  
 

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent implements OnInit {
  title = 'Claim Manager Partner Admin Portal';
  environments : IEnvironment[];
  errorMessage:string;
  constructor(private _environmentservice: EnvironmentService){
    this.environments = [];
  }

  ngOnInit(): void{
   this.getAllEnvironments().subscribe(response => this.environments = response, error => this.errorMessage = < any > error);
   // let self = this;
   // self._environmentservice.getEnvironments.subscribe(response => this.environments = response, error => this.errorMessage = < any > error)
  }

  public getAllEnvironments(): Observable<IEnvironment[]>{
    return this._environmentservice.getEnvironments();
  }
}
