import { Component, OnInit } from '@angular/core';

import { Http } from '@angular/http';
import { Router } from '@angular/router';
import { MatToolbar } from '@angular/material';


@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent implements OnInit {
  title = 'Claim Manager Partner Admin Portal';
  constructor(private http: Http, private router: Router) {
  }

  ngOnInit(): void {
  }
}
