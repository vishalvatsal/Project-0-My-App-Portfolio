import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { HttpModule } from '@angular/http';
import { MaterialModule } from './material.module';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { AppRoutingModule } from './app-routing.module';
import { GlobalConstants } from './GlobalConstants';

import { AppComponent } from './app.component';

import { EnvironmentService } from './services/environment.service';
import { FileService } from './services/file.service';
import { PartnerService } from './services/partner.services';
import { CloneDialogService } from './services/clone-Dialog.service';
import { PartnerComponent } from './components/partner/partner.component';
import { PartnerDetailsComponent } from './components/partner-details/partner-details.component';
import { DashboardComponent } from './components/dashboard/dashboard.component';
import { MarkdowneditorComponent } from './components/markdowneditor/markdowneditor.component';
import { TranslationFormComponent } from './components/translation-form/translation-form.component';
import { ConfigFormComponent } from './components/config-form/config-form.component';
import { EmailTemplatesComponent } from './components/email-templates/email-templates.component';
import { PublicImgComponent } from './components/public-img/public-img.component';
import { ImagecardsComponent } from './components/imagecards/imagecards.component';
import { CloneDialogComponent } from './components/clone-dialog/clone-dialog.component';

import { ImageCropperComponent, CropperSettings } from 'ng2-img-cropper';
import { SafeHtml } from './safehtml.pipe';
import { NgPipesModule } from 'angular-pipes';
import { FolderFilter } from './fileListFilter.pipe';
import { ColorPickerModule } from 'ngx-color-picker';
import { FieldResetComponent } from './components/field-reset/field-reset.component';


@NgModule({
  declarations: [
    AppComponent,
    ImageCropperComponent,
    ImagecardsComponent,
    PartnerComponent,
    PartnerDetailsComponent,
    DashboardComponent,
    MarkdowneditorComponent,
    TranslationFormComponent,
    EmailTemplatesComponent,
    PublicImgComponent,
    ConfigFormComponent,
    SafeHtml,
    FolderFilter,
    FieldResetComponent,
    CloneDialogComponent
  ],
  imports: [
    BrowserModule,
    FormsModule,
    ReactiveFormsModule,
    BrowserAnimationsModule,
    HttpModule,
    MaterialModule,
    AppRoutingModule,
    NgPipesModule,
    ColorPickerModule
  ],
  providers: [EnvironmentService, FileService, CloneDialogService,PartnerService],
  bootstrap: [AppComponent],
  exports: [CloneDialogComponent],
  entryComponents: [CloneDialogComponent]
})
export class AppModule { }
