import { BrowserModule } from '@angular/platform-browser';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { NgModule } from '@angular/core';
import {MdButtonModule, MdCardModule,MdMenuModule, MdToolbarModule,MdIconModule} from '@angular/material';
import { HttpModule }      from '@angular/http';
import { AppComponent } from './app.component';
import {EnvironmentService} from './shared/services/environment.service'


@NgModule({
  declarations: [
    AppComponent   
  ],
  imports: [
    BrowserModule,
    BrowserAnimationsModule,
    MdButtonModule, 
    MdCardModule,
    MdMenuModule, 
    MdToolbarModule,
    MdIconModule,
    HttpModule
  ],
  providers: [EnvironmentService],
  bootstrap: [AppComponent]
})
export class AppModule { }
