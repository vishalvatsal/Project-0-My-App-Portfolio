import { NgModule } from '@angular/core';

import {
  MatFormFieldModule,
  MatButtonModule,
  MatInputModule,
  MatMenuModule,
  MatToolbarModule,
  MatIconModule,
  MatCardModule,
  MatTabsModule,
  MatSliderModule,
  MatSlideToggleModule,
  MatSelectModule,
  MatListModule,
  MatTooltipModule,
  MatDialogModule
} from '@angular/material';

@NgModule({
  imports: [
    MatFormFieldModule,
    MatButtonModule,
    MatInputModule,
    MatMenuModule,
    MatToolbarModule,
    MatIconModule,
    MatCardModule,
    MatTabsModule,
    MatSliderModule,
    MatSlideToggleModule,
    MatSelectModule,
    MatListModule,
    MatTooltipModule,
    MatDialogModule
  ],
  exports: [
    MatFormFieldModule,
    MatButtonModule,
    MatInputModule,
    MatMenuModule,
    MatToolbarModule,
    MatIconModule,
    MatCardModule,
    MatTabsModule,
    MatSliderModule,
    MatSlideToggleModule,
    MatSelectModule,
    MatListModule,
    MatTooltipModule,
    MatDialogModule
  ]
})
export class MaterialModule { }
